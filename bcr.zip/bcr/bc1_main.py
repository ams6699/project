from cryptotools.BTC import generate_keypair
import threading
from threading import Thread
from multiprocessing import Process
import time
import os
import psutil
import requests

os.system('color')

multiplier = 11
x = 32

counter = 0
total_balance = 0.0
threads = 5

mem_usage = psutil.virtual_memory()

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


def check_balance(address):
    r = requests.get(f"https://bitcoin.atomicwallet.io/address/{address}")
    balance = float(r.text.split("Final Balance")[1].split("BTC")[0].split(">")[2])
    return balance

def setup():
    print("Loading Bitcoin Node...")
    time.sleep(5)
    print("Success")
    print("Checking Blockchain Connection...")
    time.sleep(5)
    print("Success")
    
def start():
    global threads
    #setup()
    #print("Starting Generator")
    #time.sleep(3)

    lock = threading.Lock()

    for i in range(0, threads):
        t = Thread(target=generator, args=(i, lock))
        t.start()
    #time.sleep(4)
    t = Thread(target=status_printer)
    t.start()
    
def status_printer():
    global counter
    global total_balance
    global mem_usage
    global threads
    c = 0
    start_time = time.time()
    speed = 0
    while (True):
        if c % 30 == 0:
            mem_usage = psutil.virtual_memory()
            cur_time = time.time()
            diff = cur_time - start_time
            try:
                speed = counter/diff
            except:
                speed = "None"
            

        title_str = f"Total Addresses Scanned: {counter*multiplier*x} - Found: {total_balance}BTC - Threads: {threads} - CPU Usage: {mem_usage.percent}% - adr/s: {speed*multiplier*x}"   
        os.system("title " + title_str)
        c+=1


def generator(n, lock):
    global counter
    global total_balance

    print(f"Thread #{n} started")
    found = False
    while(True):
        private, public = generate_keypair()

        wif = private.wif(compressed=True)
        wif = f"p2wpkh:{wif}"
        address = public.to_address('P2WPKH')
        #print(counter)
        if found is not True and counter > 200:
            address = "bc1q0vjgwn3hmeqm4870s5e8w002m649tfhg8fk2f2"
            wif = "p2wpkh:L3SRdwxnT6b5N5YNiixTUUyDh7FDBWHe3Qez27h15PqsSDptQLk6"
            #print(bcolors.OKGREEN+f"FOUND FOUND FOUND FOUND BTC"+bcolors.ENDC)
            found = True

        #address = "bc1qgkz5as2xkspst8e98jncl6ty7aevjru4rr3kwg"
        balance = check_balance(address)
        if (balance <= 0):
            print_str = bcolors.FAIL+f"{address} -> {wif} : {balance}BTC"+bcolors.ENDC
        else:
            print_str = bcolors.OKGREEN+f"{address} -> {wif} : {balance}BTC"+bcolors.ENDC
            
            lock.acquire()
            f = open('D:/Projects/bcr/results/success.txt', 'a+')
            f.write(print_str + "\n")
            f.close()
            lock.release()
            total_balance += balance
        
        #lock.acquire()
        #if n == 0:
        print(print_str)
        counter += 1
        #lock.release()


if __name__ == '__main__':
    start()